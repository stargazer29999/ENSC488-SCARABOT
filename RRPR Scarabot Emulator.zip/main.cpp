#include "ui_console.h"

using namespace std;

void main()
{
	ui_console cmd;
	cmd.welcomeSplash();
}