#include "robo_control.h"

using namespace std;

robo_control::robo_control()
{
	JOINT q0 = { 100,100,-100,100 };
	OpenMonitor();
}


void robo_control::move()
{
	cout << "Please enter desired joint values one at a time" << endl;
	cout << "1st joint: " << endl;
	cin >> j1;
	cout << "2nd joint: " << endl;
	cin >> j2;
	cout << "3rd joint: " << endl;
	cin >> j3;
	cout << "4th joint: " << endl;
	cin >> j4;
	cout << endl;

	JOINT q0 = { j1, j2, j3, j4 };
	MoveToConfiguration(q0, false);

	cout << "joint values are " << j1 << " " << j2 << " " << j3 << " " << j4 << endl;
	
	//DisplayConfiguration(q0);
}