#include "robo_control.h"

using namespace std;

robo_control::robo_control()
{
	JOINT q0 = { 100, 100, -100, 100 };
	OpenMonitor();

	internal_form = new double*[HEIGHT];
	for (int i = 0; i < HEIGHT; i++) {
		internal_form[i] = new double[WIDTH];
	}

	user_form = new double[HEIGHT];

	//TMULT
	t_matrix1 = new double*[HEIGHT];
	for (int i = 0; i < HEIGHT; i++) {
		t_matrix1[i] = 0;
		t_matrix1[i] = new double[WIDTH];
	}

	t_matrix2 = new double*[HEIGHT];
	for (int i = 0; i < HEIGHT; i++) {
		t_matrix2[i] = 0;
		t_matrix2[i] = new double[WIDTH];
	}

	r_matrix = new double*[HEIGHT];
	for (int i = 0; i < HEIGHT; i++) {
		r_matrix[i] = new double[WIDTH];
	}

	for (int i = 0; i < HEIGHT; i++) {
		for (int j = 0; j < WIDTH; j++) {
			r_matrix[i][j] = 0;
		}
	}
}

void robo_control::moveJOINT()
{
	cout << endl << "Please enter desired joint values" << endl;
	cout << "Joint1: ";
	cin >> user_form[0];
	cout << endl;
	cout << "Joint2: ";
	cin >> user_form[1];
	cout << endl;
	cout << "Joint3: ";
	cin >> user_form[2]; 
	cout << endl;
	cout << "Joint4: ";
	cin >> user_form[3];
	cout << endl;

	/*
	while (user_form[0] >= #  || user_form[0] <= #)
	{
		cout << "Please enter a valid x position: " << endl;
		cin >> user_form[0];
		cout << " " << endl;
	}

	while (user_form[1] >= #  || user_form[1] <= #)
	{
		cout << "Please enter a valid x position: " << endl;
		cin >> user_form[1];
		cout << " " << endl;
	}

	if (user_form[3] > 360){
		user_form[3] = user_form[3] - 360;
		user_form[3] = user_form[3] * (PI / 180);
	}
	else if (theta < -360){
		user_form[3] = user_form[3] + 360;
		user_form[3] = user_form[3] * (PI / 180);
	}
	else{
		user_form[3] = user_form[3] * (PI / 180)
	}
	*/
	internal_form = cmd.UTOI(user_form);


	JOINT q0 = { user_form[0], user_form[1], user_form[2], user_form[3] };
	MoveToConfiguration(q0, false);

	cout << "Joint values are: {" << user_form[0] << " " << user_form[1] << " " << user_form[2] << " " << user_form[3] << "}"<< endl;
	cout << "" << endl;
	
	cout << "===========================================" << endl;
	cout << "Forward Kinematics Result from WHERE(): " << endl << endl;
	cmd.printInternalMatrix(cmd.WHERE(q0));
	cout << "===========================================" << endl;
	
	cout << "Would you like to activate the gripper? Y/N" << endl;
	cin >> grip;

	if (grip == 'Y')
	{
		Grasp(true);
	}
	else{
		Grasp(false);
	}
}

void robo_control::stopRobot()
{
	StopRobot();
	CloseMonitor();
}

/*void robo_control::initCart()
{
	JOINT q0 = {0, 0, -90, 0 };
	DisplayConfiguration(q0);
}
*/

void robo_control::initJoint()
{
	JOINT q0 = { 0, 0, -150, 0 };
	Grasp(false);
	DisplayConfiguration(q0);
	cout << "Intialized...";
}

void robo_control::currentPos()
{
	JOINT q0;
	GetConfiguration(q0);
	cout << "Joint values are : " << q0[0] << " " << q0[1] << " " << q0[2] << " " << q0[3] << endl;
}

void robo_control::zeroPosition()
{
	ResetRobot();
	cout << "Reset Successful" << endl;
}