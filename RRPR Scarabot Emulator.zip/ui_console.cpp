
#include "ui_console.h"

void ui_console::welcomeSplash()
{
	//cout << "ENSC 488 - Introduction to Robotics: Demo 1 w/ WIP UI" << endl; add to main
	cout << "Press '1' for emulator, '0' for hw communcation" << endl;
	cout << "Input: ";
	cin >> select_bit;

	while (select_bit != 1 || select_bit != 0)
	{
		if (select_bit == 1)
		{
			emulatorSplash();
		}
		else if (select_bit == 0)
		{
			hwSplash();;
		}
		else
		{
			welcomeSplash();
		}
	}
}

void ui_console::emulatorSplash()
{
	cout << " " << endl;
	cout << "List of Commands, please select one by typeing corresponding command number" << endl;
	cout << "0: Quit Emulation" << endl;
	cout << "1: Rest to Zero Position" << endl;
	cout << "2: Relocate Tool Tip" << endl;
	cout << "3: Current Tool Tip Position" << endl;
	cout << "4: Current Joint Values" << endl;
	cout << "Input: ";
	
	emul_select = -1;
	cout << "" << endl;

	while (emul_select != 0 || emul_select != 1 || emul_select != 2 || emul_select != 2 || emul_select != 3 || emul_select != 4)
	{

		cin >> emul_select;
		switch (emul_select)
		{
		case 0:
			quitSplash();
			//cmd.stopRobot();
			break;
		case 1:
			//reset function call
			break;
		case 2:
			//calls neccesary function from move SCARA class
			cmd.move();
			break;
		case 3:
			//calls neccesary function from move SCARA class
			break;
		case 4:
			//calls neccesary function from move SCARA class
			break;
		default:
			emulatorSplash();
			break;
		}
	}
}

void ui_console::quitSplash()
{
	cout << "System shutting down..." << endl;
	//necceasy reset command if any
	cout << "" << endl;
	system("pause");
}

void ui_console::hwSplash()
{
}