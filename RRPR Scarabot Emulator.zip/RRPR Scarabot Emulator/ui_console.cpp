
#include "ui_console.h"

void ui_console::welcomeSplash()
{
/*	//cout << "ENSC 488 - Introduction to Robotics: Demo 1 w/ WIP UI" << endl; add to main
	cout << "Press '1' for emulator " << endl; // '0' for hw communcation" << endl;
	cout << "Input: ";
	cin >> select_bit;

	while (select_bit != 1 || select_bit != 0)
	{
		if (select_bit == 1)
		{
	*/		emulatorSplash();
/*		}
		else if (select_bit == 0)
		{
			//hwSplash();
		}
		else
		{
			welcomeSplash();
		}
	}
	*/
}

void ui_console::emulatorSplash()
{
	cout << " " << endl;
	cout << "List of Commands, please select one by typeing corresponding command number" << endl;
	cout << "0: Quit Emulation" << endl;
	cout << "1: Reset to Start Position" << endl;
	cout << "2: Initialize Robot Position" << endl;
	cout << "3: Move to X,Y,Z, Phi" << endl;
	cout << "4: Set Joint Values" << endl;
	cout << "5: Get Configuration" << endl;
	cout << "6: Get Configuration in Cartesian" << endl;
	cout << "Input: ";
	
	emul_select = -1;
	//cout << "" << endl;

	while (emul_select != 0 || emul_select != 1 || emul_select != 2 || emul_select != 2 || emul_select != 3 || emul_select != 4)
	{
		cin >> emul_select;
		cout << endl;
		switch (emul_select)
		{
		case 0: //done
			quitSplash();
			exit(-1);
			break;
		case 1:
			cmd.zeroPosition();
			break;
		case 2:
			cmd.initJoint();
			break;
		case 3:
			cmd.moveCart();
			break;
		case 4:
			cmd.moveJOINT();
			break;
		case 5:
			cmd.currentPos();
			break;
		case 6:
			cmd.currentPosCar();
			break;
		default:
			quitSplash();
			break;
		}
		emulatorSplash();
	}
}

void ui_console::quitSplash()
{
	cout << "System shutting down..." << endl;
	//necceasy reset command if any
	cout << "" << endl;
	cmd.stopRobot();
	system("pause");
}
