//This class handles commanding the emulator by using the previously developed matrix operations

#pragma once
#define ROBO_CONTROL

#include <stdio.h>
#include <iostream>
#include <string>
#include <cmath>

//#include "matrix_helper"; Place holder for when we move matrix utilities over
//#include "kinematics"; Place holder for the forward and inverse kinematics section
#include "ensc-488.h"

class robo_control
{
private:
	JOINT* q0;
	double j1, j2, j3, j4;
public:
	robo_control();
	void zeroPosition();
	void move();
	void currentPos();
	void currentJoint();
	bool stopRobot();
};